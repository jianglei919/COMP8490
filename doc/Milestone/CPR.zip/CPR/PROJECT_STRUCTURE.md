# VR CPR 训练系统 - 项目结构

## 📁 项目文件结构

```
CPR/
├── index.html                  # HTML入口文件
├── README.md                   # 项目说明文档
│
├── js/                         # JavaScript模块目录
│   ├── main.js                 # 主应用入口 - 初始化和协调所有模块
│   ├── StepManager.js          # 步骤管理器 - 管理训练流程
│   ├── environment.js          # 环境创建 - 房间、墙壁、地板
│   ├── victim.js               # 伤者模型 - 人体3D模型
│   ├── interactionObjects.js   # 交互物体 - 安全标识、急救电话
│   ├── ui.js                   # UI界面 - 指令面板和文本更新
│   ├── desktopControls.js      # 桌面控制 - 鼠标/键盘交互
│   └── vrControllers.js        # VR控制器 - VR手柄交互
```

## 📦 模块说明

### 🎯 main.js - 主应用
- 场景、相机、渲染器初始化
- 协调所有模块
- 动画循环
- 窗口事件处理

### 📋 StepManager.js - 步骤管理
- 定义4个训练步骤
- 跟踪当前步骤
- 验证步骤完成
- 生成训练总结

### 🏠 environment.js - 环境
- 创建地板和网格
- 创建墙壁
- 添加天花板灯光

### 👤 victim.js - 伤者模型
- 创建躺平的人体模型
- 头部、躯干、手臂、腿部
- 肩膀和胸部交互标记
- 急救垫

### 🎯 interactionObjects.js - 交互物体
- 黄色安全标识（步骤1）
- 红色急救电话（步骤3）

### 💬 ui.js - 用户界面
- 创建指令面板
- 更新步骤文本
- 显示按压计数
- 控制标记可见性

### 🖱️ desktopControls.js - 桌面控制
- OrbitControls 相机控制
- 鼠标悬停高亮
- 鼠标点击交互
- 光线投射检测

### 🎮 vrControllers.js - VR控制器
- VR手柄设置
- 手柄射线可视化
- 触发器按钮事件
- VR交互处理

## 🔄 模块依赖关系

```
main.js
  ├─→ StepManager.js
  ├─→ environment.js
  ├─→ victim.js
  ├─→ interactionObjects.js
  ├─→ ui.js
  │    └─→ StepManager (使用)
  ├─→ desktopControls.js
  │    └─→ StepManager (使用)
  └─→ vrControllers.js
       └─→ StepManager (使用)
```

## ✨ 优势

### 1. **模块化设计**
- 每个文件专注单一功能
- 易于理解和维护
- 便于团队协作

### 2. **代码复用**
- 功能独立，可在其他项目使用
- 清晰的导入/导出

### 3. **易于扩展**
- 添加新步骤：修改 StepManager.js
- 添加新物体：修改 interactionObjects.js
- 改进UI：修改 ui.js

### 4. **便于测试**
- 可以单独测试每个模块
- 依赖关系清晰

## 🚀 如何使用

1. **启动服务器**
   ```bash
   python3 -m http.server 8000
   ```

2. **访问应用**
   ```
   http://localhost:8000
   ```

3. **修改代码**
   - 打开对应的模块文件
   - 修改后刷新浏览器即可看到效果

## 📝 常见修改场景

### 添加新的训练步骤
→ 编辑 `js/StepManager.js`

### 修改人体模型外观
→ 编辑 `js/victim.js`

### 调整房间布局
→ 编辑 `js/environment.js`

### 改变指令文本样式
→ 编辑 `js/ui.js`

### 调整相机视角
→ 编辑 `js/main.js` 和 `js/desktopControls.js`

## 🎓 学习路径

推荐按以下顺序阅读代码：
1. `main.js` - 了解整体结构
2. `StepManager.js` - 理解训练流程
3. `environment.js` - 场景构建
4. `victim.js` - 3D模型创建
5. `ui.js` - UI交互
6. `desktopControls.js` / `vrControllers.js` - 用户输入处理
