/**
 * ============================================
 * 步骤管理器 - 管理训练步骤流程
 * ============================================
 * 
 * 职责：
 * - 定义训练步骤序列
 * - 跟踪当前步骤进度
 * - 验证步骤完成
 * - 生成训练总结报告
 */

export class StepManager {
    constructor() {
        // 定义训练步骤序列
        this.steps = [
            { 
                id: "CHECK_SAFETY", 
                text: "步骤 1：检查现场是否安全\n点击墙上的黄色安全标识", 
                type: "CHECK_SAFETY",
                completed: false
            },
            { 
                id: "CHECK_RESPONSIVENESS", 
                text: "步骤 2：拍打伤者肩膀并呼喊\n点击伤者肩部的橙色区域", 
                type: "TAP_SHOULDERS",
                completed: false
            },
            { 
                id: "CALL_EMERGENCY", 
                text: "步骤 3：拨打急救电话\n点击墙上的红色急救电话", 
                type: "CALL_EMERGENCY",
                completed: false
            },
            { 
                id: "START_COMPRESSIONS", 
                text: "步骤 4：开始胸外按压\n连续点击伤者胸部的红色标记 5 次", 
                type: "CHEST_COMPRESSIONS",
                completed: false,
                compressionCount: 0,           // 当前按压次数
                requiredCompressions: 5        // 需要的按压次数
            }
        ];
        this.currentIndex = 0; // 当前步骤索引
    }

    /**
     * 获取当前步骤
     * @returns {Object} 当前步骤对象
     */
    getCurrentStep() {
        return this.steps[this.currentIndex];
    }

    /**
     * 完成当前步骤并前进到下一步
     * @returns {boolean} 是否成功完成步骤
     */
    completeCurrentStep() {
        if (!this.isFinished()) {
            this.steps[this.currentIndex].completed = true;
            this.currentIndex++;
            return true;
        }
        return false;
    }

    /**
     * 检查是否完成所有步骤
     * @returns {boolean} 是否已完成训练
     */
    isFinished() {
        return this.currentIndex >= this.steps.length;
    }

    /**
     * 生成训练总结报告
     * @returns {string} 格式化的总结文本
     */
    getSummary() {
        let summary = "训练完成！\n\n";
        this.steps.forEach((step, index) => {
            const stepName = [
                "检查现场安全",
                "检查伤者反应", 
                "拨打急救电话",
                "胸外按压"
            ][index];
            summary += `步骤 ${index + 1}：${stepName} - ${step.completed ? '✓ 已完成' : '✗ 未完成'}\n`;
        });
        return summary;
    }
}
