import * as THREE from 'three';
import { XRControllerModelFactory } from 'three/addons/webxr/XRControllerModelFactory.js';
import { audioManager } from './audioManager.js';

// ============================================
// VR CONTROLLERS - VR手柄控制器
// ============================================
export function setupVRControllers(renderer, scene, interactableObjects, stepManager, updateUI) {
    const controllerModelFactory = new XRControllerModelFactory();
    const raycaster = new THREE.Raycaster();

    // Controller 1
    const controller1 = renderer.xr.getController(0);
    controller1.addEventListener('selectstart', (event) => onSelectStart(event, raycaster, interactableObjects, stepManager, updateUI));
    controller1.addEventListener('selectend', onSelectEnd);
    scene.add(controller1);

    const controllerGrip1 = renderer.xr.getControllerGrip(0);
    controllerGrip1.add(controllerModelFactory.createControllerModel(controllerGrip1));
    scene.add(controllerGrip1);

    // Controller 2
    const controller2 = renderer.xr.getController(1);
    controller2.addEventListener('selectstart', (event) => onSelectStart(event, raycaster, interactableObjects, stepManager, updateUI));
    controller2.addEventListener('selectend', onSelectEnd);
    scene.add(controller2);

    const controllerGrip2 = renderer.xr.getControllerGrip(1);
    controllerGrip2.add(controllerModelFactory.createControllerModel(controllerGrip2));
    scene.add(controllerGrip2);

    // Add visual ray to controllers
    const geometry = new THREE.BufferGeometry().setFromPoints([
        new THREE.Vector3(0, 0, 0),
        new THREE.Vector3(0, 0, -1)
    ]);
    const material = new THREE.LineBasicMaterial({ color: 0x00ffff });
    
    const line1 = new THREE.Line(geometry, material);
    line1.scale.z = 5;
    controller1.add(line1.clone());
    
    const line2 = new THREE.Line(geometry, material);
    line2.scale.z = 5;
    controller2.add(line2.clone());
}

function onSelectStart(event, raycaster, interactableObjects, stepManager, updateUI) {
    const controller = event.target;
    handleVRInteraction(controller, raycaster, interactableObjects, stepManager, updateUI);
}

function onSelectEnd(event) {
    // Optional: handle release if needed
}

function handleVRInteraction(controller, raycaster, interactableObjects, stepManager, updateUI) {
    if (stepManager.isFinished()) {
        return;
    }

    // Create a ray from the controller
    const tempMatrix = new THREE.Matrix4();
    tempMatrix.identity().extractRotation(controller.matrixWorld);
    
    raycaster.ray.origin.setFromMatrixPosition(controller.matrixWorld);
    raycaster.ray.direction.set(0, 0, -1).applyMatrix4(tempMatrix);

    // Check for intersections with interactable objects
    const intersects = raycaster.intersectObjects(interactableObjects, true);

    if (intersects.length > 0) {
        const hitObject = intersects[0].object;
        const currentStep = stepManager.getCurrentStep();

        // Check if the hit object matches the current step type
        if (hitObject.userData.type === currentStep.type) {
            // 恢复 AudioContext
            audioManager.resume();
            
            // Special handling for compressions
            if (currentStep.type === "CHEST_COMPRESSIONS") {
                currentStep.compressionCount++;
                updateUI();
                
                // 播放按压音效
                audioManager.playChestCompression();
                
                // Visual feedback
                hitObject.material.emissive = new THREE.Color(0xff0000);
                setTimeout(() => {
                    hitObject.material.emissive = new THREE.Color(0x000000);
                }, 100);
                
                if (currentStep.compressionCount >= currentStep.requiredCompressions) {
                    stepManager.completeCurrentStep();
                    updateUI();
                    // 播放步骤完成音效
                    audioManager.playStepComplete();
                }
            } else {
                // 根据不同类型播放不同音效
                if (currentStep.type === "CHECK_SAFETY") {
                    audioManager.playButtonClick();
                } else if (currentStep.type === "TAP_SHOULDERS") {
                    audioManager.playTapShoulder();
                } else if (currentStep.type === "CALL_EMERGENCY") {
                    audioManager.playEmergencyCall();
                }
                
                // Complete step immediately for other types
                stepManager.completeCurrentStep();
                updateUI();
                
                // 播放步骤完成音效
                audioManager.playStepComplete();
                
                // Visual feedback
                hitObject.material.emissive = new THREE.Color(0x00ff00);
                setTimeout(() => {
                    if (hitObject.material.emissive) {
                        hitObject.material.emissive = new THREE.Color(0x000000);
                    }
                }, 200);
            }
        }
    }
}
