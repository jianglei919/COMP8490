import * as THREE from 'three';

// ============================================
// UI PANEL - 创建和更新指令面板
// ============================================
export function createInstructionPanel(scene) {
    // Create a canvas for text rendering
    const canvas = document.createElement('canvas');
    canvas.width = 1024;
    canvas.height = 512;
    const context = canvas.getContext('2d');
    
    // Create texture from canvas
    const texture = new THREE.CanvasTexture(canvas);
    
    // Create panel mesh
    // 电视屏幕效果：带边框与微玻璃质感
    const panelGeometry = new THREE.PlaneGeometry(2.4, 1.35);
    const panelMaterial = new THREE.MeshPhysicalMaterial({ 
        map: texture,
        transparent: true,
        side: THREE.FrontSide,
        roughness: 0.3,
        reflectivity: 0.6,
        clearcoat: 0.3,
        clearcoatRoughness: 0.4
    });
    const instructionPanel = new THREE.Mesh(panelGeometry, panelMaterial);
    // 将屏幕放置在蓝色分割线（y=1.2）上方
    instructionPanel.position.set(0, 2.3, -6.77);
    scene.add(instructionPanel);

    // 边框（黑色电视边框）
    const bezel = new THREE.Mesh(
        new THREE.PlaneGeometry(2.55, 1.5),
        new THREE.MeshStandardMaterial({ color: 0x111111, roughness: 0.6 })
    );
    bezel.position.copy(instructionPanel.position);
    bezel.position.z -= 0.01;
    scene.add(bezel);
    
    // Store canvas for updates
    instructionPanel.userData.canvas = canvas;
    instructionPanel.userData.context = context;
    instructionPanel.userData.texture = texture;
    
    return instructionPanel;
}

export function updateInstructionText(instructionPanel, stepManager, victimShoulders, victimChest) {
    const canvas = instructionPanel.userData.canvas;
    const context = instructionPanel.userData.context;
    const texture = instructionPanel.userData.texture;
    
    // Clear canvas
    context.fillStyle = 'rgba(0, 0, 0, 0.8)';
    context.fillRect(0, 0, canvas.width, canvas.height);
    
    // Draw border
    context.strokeStyle = '#00ffff';
    context.lineWidth = 10;
    context.strokeRect(10, 10, canvas.width - 20, canvas.height - 20);
    
    // Draw text
    context.fillStyle = '#ffffff';
    context.font = 'bold 48px Arial';
    context.textAlign = 'center';
    
    let text;
    if (stepManager.isFinished()) {
        text = stepManager.getSummary();
        context.fillStyle = '#00ff00';
        context.font = 'bold 56px Arial';
    } else {
        text = stepManager.getCurrentStep().text;
        
        // Show compression count for step 4
        const currentStep = stepManager.getCurrentStep();
        if (currentStep.type === "CHEST_COMPRESSIONS") {
            text += `\n\n按压次数：${currentStep.compressionCount}/${currentStep.requiredCompressions}`;
        }
    }
    
    // Draw multi-line text
    const lines = text.split('\n');
    const lineHeight = 60;
    const startY = (canvas.height - (lines.length * lineHeight)) / 2 + 40;
    
    lines.forEach((line, index) => {
        context.fillText(line, canvas.width / 2, startY + (index * lineHeight));
    });
    
    texture.needsUpdate = true;
    
    // Update visual markers
    updateStepVisuals(stepManager, victimShoulders, victimChest);
}

function updateStepVisuals(stepManager, victimShoulders, victimChest) {
    const currentStep = stepManager.getCurrentStep();
    
    // Hide all markers first
    if (victimShoulders) victimShoulders.material.opacity = 0.0;
    if (victimChest) victimChest.material.opacity = 0.0;
    
    // Show only the marker for current step with high visibility
    if (!stepManager.isFinished()) {
        if (currentStep.type === "TAP_SHOULDERS" && victimShoulders) {
            victimShoulders.material.opacity = 0.85;
        } else if (currentStep.type === "CHEST_COMPRESSIONS" && victimChest) {
            victimChest.material.opacity = 0.9;
        }
    }
}
