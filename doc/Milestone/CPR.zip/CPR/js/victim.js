import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';

/**
 * ============================================
 * 伤者模型 - 创建躺平的人体3D模型
 * ============================================
 * 
 * 职责：
 * - 创建人体各部位（头、躯干、四肢）
 * - 添加交互标记（肩膀、胸部）
 * - 设置急救垫
 */

/**
 * 创建伤者模型
 * @param {THREE.Scene} scene - Three.js 场景对象
 * @param {Array} interactableObjects - 可交互物体数组
 * @returns {Object} 包含伤者部件的对象
 */
export function createVictim(scene, interactableObjects) {
    // 创建容器组
    const victimGroup = new THREE.Group();
    // 将伤者抬高到床面高度
    victimGroup.position.set(0, 0.35, -2);
    // 让床头朝向后墙（旋转180度使头部指向负Z方向）
    victimGroup.rotation.y = Math.PI;
    scene.add(victimGroup);

    // 交互标记（始终存在于场景中）
    const shouldersGeometry = new THREE.BoxGeometry(0.55, 0.08, 0.05);
    // const shouldersGeometry = new THREE.CylinderGeometry(0.2, 0.05, 0.065, 8);
    const shouldersMaterial = new THREE.MeshStandardMaterial({ 
        color: 0xff6600,
        emissive: 0xff6600,
        emissiveIntensity: 0.8,
        transparent: true,
        opacity: 0.3
    });
    const victimShoulders = new THREE.Mesh(shouldersGeometry, shouldersMaterial);
    // victimShoulders.position.set(0, 0.1, 0.62);
    victimShoulders.position.set(0, 0.13, 0.7);
    victimShoulders.userData.type = "TAP_SHOULDERS";
    victimGroup.add(victimShoulders);

    // 创建心形几何体
    const heartShape = new THREE.Shape();
    const x = 0, y = 0;
    heartShape.moveTo(x + 0, y + 0.08);
    heartShape.bezierCurveTo(x + 0, y + 0.12, x - 0.04, y + 0.16, x - 0.08, y + 0.16);
    heartShape.bezierCurveTo(x - 0.16, y + 0.16, x - 0.16, y + 0.08, x - 0.16, y + 0.08);
    heartShape.bezierCurveTo(x - 0.16, y + 0, x - 0.08, y - 0.08, x + 0, y - 0.16);
    heartShape.bezierCurveTo(x + 0.08, y - 0.08, x + 0.16, y + 0, x + 0.16, y + 0.08);
    heartShape.bezierCurveTo(x + 0.16, y + 0.08, x + 0.16, y + 0.16, x + 0.08, y + 0.16);
    heartShape.bezierCurveTo(x + 0.04, y + 0.16, x + 0, y + 0.12, x + 0, y + 0.08);
    
    const extrudeSettings = {
        depth: 0.06,
        bevelEnabled: true,
        bevelThickness: 0.01,
        bevelSize: 0.01,
        bevelSegments: 3
    };
    
    const chestGeometry = new THREE.ExtrudeGeometry(heartShape, extrudeSettings);
    const chestMaterial = new THREE.MeshStandardMaterial({ 
        color: 0xff0000,
        emissive: 0xff0000,
        emissiveIntensity: 1.0,
        transparent: true,
        opacity: 0.3
    });
    const victimChest = new THREE.Mesh(chestGeometry, chestMaterial);
    victimChest.position.set(0, 0.25, 0.58);
    victimChest.rotation.x = Math.PI / 2; // 让心形平躺在胸部上
    victimChest.scale.set(0.5, 0.5, 0.5); // 放大1.5倍，改数字调整大小
    victimChest.userData.type = "CHEST_COMPRESSIONS";
    victimGroup.add(victimChest);

    // 床（替换地垫）：包含床垫与床架
    const bedGroup = new THREE.Group();
    bedGroup.position.set(0, -0.35, 0); // 相对伤者组的底部位置

    // 床垫
    const mattress = new THREE.Mesh(
        new THREE.BoxGeometry(2.0, 0.2, 3.0),
        new THREE.MeshStandardMaterial({ color: 0xddddff, roughness: 0.8 })
    );
    mattress.position.set(0, 0.2, 0);
    bedGroup.add(mattress);

    // 床架
    const frameMaterial = new THREE.MeshStandardMaterial({ color: 0x555555, roughness: 0.7, metalness: 0.2 });
    const frame = new THREE.Mesh(new THREE.BoxGeometry(2.05, 0.1, 3.05), frameMaterial);
    frame.position.set(0, 0.05, 0);
    bedGroup.add(frame);

    // 四个床腿
    const legGeom = new THREE.BoxGeometry(0.08, 0.35, 0.08);
    const mkLeg = (x, z) => {
        const leg = new THREE.Mesh(legGeom, frameMaterial);
        leg.position.set(x, -0.1, z);
        return leg;
    };
    bedGroup.add(mkLeg(0.95, 1.45));
    bedGroup.add(mkLeg(-0.95, 1.45));
    bedGroup.add(mkLeg(0.95, -1.45));
    bedGroup.add(mkLeg(-0.95, -1.45));

    // 床头板
    const headboard = new THREE.Mesh(new THREE.BoxGeometry(2.05, 0.5, 0.1), frameMaterial);
    headboard.position.set(0, 0.45, 1.55);
    bedGroup.add(headboard);

    victimGroup.add(bedGroup);

    // 尝试加载外部GLB模型，如失败则回退到原有简易几何体
    const loader = new GLTFLoader();
    const modelPath = 'models/victim.glb';

    loader.load(
        modelPath,
        (gltf) => {
            const model = gltf.scene;
            // 让模型从站立状态旋转到平躺
            model.rotation.x = -Math.PI / 2;
            model.rotation.y = 0;
            model.rotation.z = Math.PI;
            // 让模型平躺在床上
            model.position.set(0, 0.12, 0);
            // 可根据模型大小调整缩放
            const s = 0.05;
            model.scale.set(s, s, s);
            victimGroup.add(model);
        },
        undefined,
        (err) => {
            console.warn('GLB模型加载失败，使用优化后的几何体作为回退:', err?.message || err);
            // 回退：构建更真实的人体几何
            const skinMaterial = new THREE.MeshStandardMaterial({ color: 0xffdbac, roughness: 0.8 });
            const shirtMaterial = new THREE.MeshStandardMaterial({ color: 0x5588cc, roughness: 0.7 });
            const pantsMaterial = new THREE.MeshStandardMaterial({ color: 0x334455, roughness: 0.8 });

            // 头部（椭圆形）
            const head = new THREE.Mesh(new THREE.SphereGeometry(0.13, 32, 32), skinMaterial);
            head.position.set(0, 0.13, 0.6);
            head.scale.set(1, 1.1, 0.95);
            victimGroup.add(head);

            // 颈部
            const neck = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.08, 0.1), skinMaterial);
            neck.position.set(0, 0.13, 0.48);
            neck.rotation.x = Math.PI / 2;
            victimGroup.add(neck);

            // 躯干上半部分（胸部）
            const upperTorso = new THREE.Mesh(new THREE.CapsuleGeometry(0.18, 0.35, 8, 16), shirtMaterial);
            upperTorso.position.set(0, 0.13, 0.15);
            upperTorso.rotation.z = Math.PI / 2;
            victimGroup.add(upperTorso);

            // 躯干下半部分（腹部）
            const lowerTorso = new THREE.Mesh(new THREE.CapsuleGeometry(0.16, 0.25, 8, 16), shirtMaterial);
            lowerTorso.position.set(0, 0.13, -0.1);
            lowerTorso.rotation.z = Math.PI / 2;
            victimGroup.add(lowerTorso);

            // 左臂上臂
            const leftUpperArm = new THREE.Mesh(new THREE.CapsuleGeometry(0.055, 0.22, 8, 16), shirtMaterial);
            leftUpperArm.position.set(-0.26, 0.12, 0.15);
            leftUpperArm.rotation.z = Math.PI / 2;
            leftUpperArm.rotation.y = Math.PI / 12;
            victimGroup.add(leftUpperArm);

            // 左臂前臂
            const leftForearm = new THREE.Mesh(new THREE.CapsuleGeometry(0.05, 0.2, 8, 16), skinMaterial);
            leftForearm.position.set(-0.48, 0.11, 0.1);
            leftForearm.rotation.z = Math.PI / 2;
            leftForearm.rotation.y = Math.PI / 10;
            victimGroup.add(leftForearm);

            // 左手
            const leftHand = new THREE.Mesh(new THREE.SphereGeometry(0.055, 16, 16), skinMaterial);
            leftHand.position.set(-0.62, 0.11, 0.05);
            leftHand.scale.set(1.2, 0.8, 1);
            victimGroup.add(leftHand);

            // 右臂上臂
            const rightUpperArm = new THREE.Mesh(new THREE.CapsuleGeometry(0.055, 0.22, 8, 16), shirtMaterial);
            rightUpperArm.position.set(0.26, 0.12, 0.15);
            rightUpperArm.rotation.z = Math.PI / 2;
            rightUpperArm.rotation.y = -Math.PI / 12;
            victimGroup.add(rightUpperArm);

            // 右臂前臂
            const rightForearm = new THREE.Mesh(new THREE.CapsuleGeometry(0.05, 0.2, 8, 16), skinMaterial);
            rightForearm.position.set(0.48, 0.11, 0.1);
            rightForearm.rotation.z = Math.PI / 2;
            rightForearm.rotation.y = -Math.PI / 10;
            victimGroup.add(rightForearm);

            // 右手
            const rightHand = new THREE.Mesh(new THREE.SphereGeometry(0.055, 16, 16), skinMaterial);
            rightHand.position.set(0.62, 0.11, 0.05);
            rightHand.scale.set(1.2, 0.8, 1);
            victimGroup.add(rightHand);

            // 左腿大腿
            const leftThigh = new THREE.Mesh(new THREE.CapsuleGeometry(0.1, 0.35, 8, 16), pantsMaterial);
            leftThigh.position.set(-0.11, 0.12, -0.35);
            leftThigh.rotation.z = Math.PI / 2;
            victimGroup.add(leftThigh);

            // 左腿小腿
            const leftCalf = new THREE.Mesh(new THREE.CapsuleGeometry(0.08, 0.32, 8, 16), pantsMaterial);
            leftCalf.position.set(-0.11, 0.11, -0.7);
            leftCalf.rotation.z = Math.PI / 2;
            victimGroup.add(leftCalf);

            // 左脚
            const leftFoot = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.08, 0.22), new THREE.MeshStandardMaterial({ color: 0x222222, roughness: 0.9 }));
            leftFoot.position.set(-0.11, 0.08, -0.95);
            victimGroup.add(leftFoot);

            // 右腿大腿
            const rightThigh = new THREE.Mesh(new THREE.CapsuleGeometry(0.1, 0.35, 8, 16), pantsMaterial);
            rightThigh.position.set(0.11, 0.12, -0.35);
            rightThigh.rotation.z = Math.PI / 2;
            victimGroup.add(rightThigh);

            // 右腿小腿
            const rightCalf = new THREE.Mesh(new THREE.CapsuleGeometry(0.08, 0.32, 8, 16), pantsMaterial);
            rightCalf.position.set(0.11, 0.11, -0.7);
            rightCalf.rotation.z = Math.PI / 2;
            victimGroup.add(rightCalf);

            // 右脚
            const rightFoot = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.08, 0.22), new THREE.MeshStandardMaterial({ color: 0x222222, roughness: 0.9 }));
            rightFoot.position.set(0.11, 0.08, -0.95);
            victimGroup.add(rightFoot);
        }
    );

    // 添加到可交互物体数组
    interactableObjects.push(victimShoulders, victimChest);

    return {
        group: victimGroup,
        shoulders: victimShoulders,
        chest: victimChest
    };
}
