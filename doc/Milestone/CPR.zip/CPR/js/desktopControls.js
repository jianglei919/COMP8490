import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { audioManager } from './audioManager.js';

// ============================================
// DESKTOP CONTROLS - 桌面鼠标键盘控制
// ============================================
export function setupDesktopControls(camera, renderer, interactableObjects, stepManager, updateUI) {
    // OrbitControls for camera movement with mouse
    const controls = new OrbitControls(camera, renderer.domElement);
    controls.target.set(0, 0.2, -2); // Look at the victim on the ground
    controls.update();
    controls.enableDamping = true;
    controls.dampingFactor = 0.05;
    controls.minDistance = 1;
    controls.maxDistance = 10;
    controls.maxPolarAngle = Math.PI / 2; // 不能转到地板下面

    // Mouse for raycasting
    const mouse = new THREE.Vector2();
    const raycaster = new THREE.Raycaster();
    let hoveredObject = null;

    // Mouse move event for highlighting
    window.addEventListener('mousemove', (event) => {
        onMouseMove(event, mouse, raycaster, camera, interactableObjects, stepManager, hoveredObject);
    });
    
    // Mouse click event for interaction
    window.addEventListener('click', (event) => {
        onMouseClick(event, mouse, raycaster, camera, interactableObjects, stepManager, updateUI);
    });
    
    return { controls, raycaster };
}

function onMouseMove(event, mouse, raycaster, camera, interactableObjects, stepManager, hoveredObject) {
    // Calculate mouse position in normalized device coordinates (-1 to +1)
    mouse.x = (event.clientX / window.innerWidth) * 2 - 1;
    mouse.y = -(event.clientY / window.innerHeight) * 2 + 1;

    // Update raycaster
    raycaster.setFromCamera(mouse, camera);

    // Check for intersections
    const intersects = raycaster.intersectObjects(interactableObjects, true);

    // Reset previous hovered object
    if (hoveredObject && hoveredObject.material.emissive) {
        hoveredObject.material.emissive.setHex(hoveredObject.userData.originalEmissive || 0x000000);
    }

    // Highlight new hovered object
    if (intersects.length > 0 && !stepManager.isFinished()) {
        hoveredObject = intersects[0].object;
        if (!hoveredObject.userData.originalEmissive) {
            hoveredObject.userData.originalEmissive = hoveredObject.material.emissive.getHex();
        }
        
        const currentStep = stepManager.getCurrentStep();
        if (hoveredObject.userData.type === currentStep.type) {
            hoveredObject.material.emissive.setHex(0x444444);
            document.body.style.cursor = 'pointer';
        } else {
            document.body.style.cursor = 'default';
        }
    } else {
        hoveredObject = null;
        document.body.style.cursor = 'default';
    }
}

function onMouseClick(event, mouse, raycaster, camera, interactableObjects, stepManager, updateUI) {
    if (stepManager.isFinished()) {
        return;
    }

    // Update raycaster
    raycaster.setFromCamera(mouse, camera);

    // Check for intersections
    const intersects = raycaster.intersectObjects(interactableObjects, true);

    if (intersects.length > 0) {
        const hitObject = intersects[0].object;
        const currentStep = stepManager.getCurrentStep();

        // Check if the hit object matches the current step type
        if (hitObject.userData.type === currentStep.type) {
            // 恢复 AudioContext（首次用户交互）
            audioManager.resume();
            
            // Special handling for compressions
            if (currentStep.type === "CHEST_COMPRESSIONS") {
                currentStep.compressionCount++;
                updateUI();
                
                // 播放按压音效
                audioManager.playChestCompression();
                
                // Visual feedback
                hitObject.material.emissive.setHex(0xff0000);
                setTimeout(() => {
                    hitObject.material.emissive.setHex(hitObject.userData.originalEmissive || 0x000000);
                }, 100);
                
                if (currentStep.compressionCount >= currentStep.requiredCompressions) {
                    stepManager.completeCurrentStep();
                    updateUI();
                    // 播放步骤完成音效
                    audioManager.playStepComplete();
                }
            } else {
                // 根据不同类型播放不同音效
                if (currentStep.type === "CHECK_SAFETY") {
                    audioManager.playButtonClick();
                } else if (currentStep.type === "TAP_SHOULDERS") {
                    audioManager.playTapShoulder();
                } else if (currentStep.type === "CALL_EMERGENCY") {
                    audioManager.playEmergencyCall();
                }
                
                // Complete step immediately for other types
                stepManager.completeCurrentStep();
                updateUI();
                
                // 播放步骤完成音效
                audioManager.playStepComplete();
                
                // Visual feedback
                hitObject.material.emissive.setHex(0x00ff00);
                setTimeout(() => {
                    if (hitObject.material.emissive) {
                        hitObject.material.emissive.setHex(hitObject.userData.originalEmissive || 0x000000);
                    }
                }, 200);
            }
        }
    }
}
