import * as THREE from 'three';

/**
 * ============================================
 * 环境场景 - 创建训练房间环境
 * ============================================
 * 
 * 职责：
 * - 创建地板和网格
 * - 创建房间墙壁
 * - 添加天花板灯光装饰
 */

/**
 * 创建训练环境
 * @param {THREE.Scene} scene - Three.js 场景对象
 */
export function createEnvironment(scene) {
    // 创建木纹拼接地板（程序纹理）
    const woodCanvas = document.createElement('canvas');
    woodCanvas.width = 512;
    woodCanvas.height = 512;
    const woodCtx = woodCanvas.getContext('2d');
    
    // 绘制木纹地砖拼接效果
    const tileSize = 128;
    const colors = ['#8B7355', '#9B8265', '#A89276', '#8A6F47'];
    for (let y = 0; y < 4; y++) {
        for (let x = 0; x < 4; x++) {
            const colorIndex = (x + y) % colors.length;
            woodCtx.fillStyle = colors[colorIndex];
            woodCtx.fillRect(x * tileSize, y * tileSize, tileSize, tileSize);
            
            // 木纹纹理模拟（竖向条纹）
            woodCtx.strokeStyle = 'rgba(0,0,0,0.1)';
            woodCtx.lineWidth = 1;
            for (let i = 0; i < 10; i++) {
                const offsetX = Math.random() * tileSize;
                woodCtx.beginPath();
                woodCtx.moveTo(x * tileSize + offsetX, y * tileSize);
                woodCtx.lineTo(x * tileSize + offsetX, (y + 1) * tileSize);
                woodCtx.stroke();
            }
            
            // 地砖间隙
            woodCtx.strokeStyle = '#5a4a38';
            woodCtx.lineWidth = 2;
            woodCtx.strokeRect(x * tileSize + 1, y * tileSize + 1, tileSize - 2, tileSize - 2);
        }
    }
    
    const woodTexture = new THREE.CanvasTexture(woodCanvas);
    woodTexture.wrapS = woodTexture.wrapT = THREE.RepeatWrapping;
    woodTexture.repeat.set(4, 4);
    
    const floorGeometry = new THREE.PlaneGeometry(15, 15);
    const floorMaterial = new THREE.MeshPhysicalMaterial({ 
        map: woodTexture,
        roughness: 0.75,
        metalness: 0.05,
        clearcoat: 0.15,
        clearcoatRoughness: 0.6
    });
    const floor = new THREE.Mesh(floorGeometry, floorMaterial);
    floor.rotation.x = -Math.PI / 2;
    floor.receiveShadow = true;
    scene.add(floor);

    // 房间墙壁材质（纯白色）
    const wallMaterial = new THREE.MeshStandardMaterial({ 
        color: 0xffffff,
        roughness: 0.8
    });
    
    // 后墙
    const backWall = new THREE.Mesh(
        new THREE.PlaneGeometry(15, 4),
        wallMaterial
    );
    backWall.position.set(0, 2, -7);
    scene.add(backWall);
    
    // 左墙
    const leftWall = new THREE.Mesh(
        new THREE.PlaneGeometry(15, 4),
        wallMaterial
    );
    leftWall.position.set(-7, 2, 0);
    leftWall.rotation.y = Math.PI / 2;
    scene.add(leftWall);
    
    // 右墙
    const rightWall = new THREE.Mesh(
        new THREE.PlaneGeometry(15, 4),
        wallMaterial
    );
    rightWall.position.set(7, 2, 0);
    rightWall.rotation.y = -Math.PI / 2;
    scene.add(rightWall);

    // 墙面装饰：踢脚线、蓝色分隔线
    const trimMaterial = new THREE.MeshStandardMaterial({ color: 0xd0d0d0, roughness: 0.7 });
    const darkTrimMaterial = new THREE.MeshStandardMaterial({ color: 0xa8a8aa, roughness: 0.6 });
    const blueDividerMaterial = new THREE.MeshStandardMaterial({ color: 0x4A90E2, roughness: 0.6, metalness: 0.1 });
    
    // 后墙装饰
    // 踢脚线
    const backBaseboard = new THREE.Mesh(new THREE.BoxGeometry(15, 0.15, 0.05), darkTrimMaterial);
    backBaseboard.position.set(0, 0.075, -6.97);
    scene.add(backBaseboard);
    // 蓝色水平分隔线（腰线位置，屏幕会放在此线上方）
    const backDivider = new THREE.Mesh(new THREE.BoxGeometry(15, 0.06, 0.04), blueDividerMaterial);
    backDivider.position.set(0, 1.2, -6.97);
    scene.add(backDivider);
    
    // 左墙装饰
    const leftBaseboard = new THREE.Mesh(new THREE.BoxGeometry(15, 0.15, 0.05), darkTrimMaterial);
    leftBaseboard.position.set(-6.97, 0.075, 0);
    leftBaseboard.rotation.y = Math.PI / 2;
    scene.add(leftBaseboard);
    const leftDivider = new THREE.Mesh(new THREE.BoxGeometry(15, 0.06, 0.04), blueDividerMaterial);
    leftDivider.position.set(-6.97, 1.2, 0);
    leftDivider.rotation.y = Math.PI / 2;
    scene.add(leftDivider);
    
    // 右墙装饰
    const rightBaseboard = new THREE.Mesh(new THREE.BoxGeometry(15, 0.15, 0.05), darkTrimMaterial);
    rightBaseboard.position.set(6.97, 0.075, 0);
    rightBaseboard.rotation.y = Math.PI / 2;
    scene.add(rightBaseboard);
    const rightDivider = new THREE.Mesh(new THREE.BoxGeometry(15, 0.06, 0.04), blueDividerMaterial);
    rightDivider.position.set(6.97, 1.2, 0);
    rightDivider.rotation.y = Math.PI / 2;
    scene.add(rightDivider);

    // 急救培训墙面装饰
    
    // 数字时钟（后墙右上角）- 显示当前时间
    const clockCanvas = document.createElement('canvas');
    clockCanvas.width = 256;
    clockCanvas.height = 128;
    const clockCtx = clockCanvas.getContext('2d');
    
    function updateDigitalClock() {
        const now = new Date();
        const hours = String(now.getHours()).padStart(2, '0');
        const minutes = String(now.getMinutes()).padStart(2, '0');
        const seconds = String(now.getSeconds()).padStart(2, '0');
        const timeString = `${hours}:${minutes}:${seconds}`;
        
        clockCtx.fillStyle = '#1a1a1a';
        clockCtx.fillRect(0, 0, 256, 128);
        clockCtx.fillStyle = '#00ff00';
        clockCtx.font = 'bold 48px monospace';
        clockCtx.textAlign = 'center';
        clockCtx.textBaseline = 'middle';
        clockCtx.fillText(timeString, 128, 64);
        clockTexture.needsUpdate = true;
    }
    
    const clockTexture = new THREE.CanvasTexture(clockCanvas);
    const digitalClock = new THREE.Mesh(
        new THREE.PlaneGeometry(1.0, 0.5),
        new THREE.MeshBasicMaterial({ map: clockTexture })
    );
    // 放置在屏幕正上方，增加间距（屏幕顶部约3.075，时钟底部约3.5，间距约0.4米）
    digitalClock.position.set(0, 3.5, -6.9);
    scene.add(digitalClock);
    
    // 每秒更新时钟
    updateDigitalClock();
    setInterval(updateDigitalClock, 1000);
    
    // 时钟边框
    const clockFrame = new THREE.Mesh(
        new THREE.PlaneGeometry(1.1, 0.6),
        new THREE.MeshStandardMaterial({ color: 0x333333, roughness: 0.6 })
    );
    clockFrame.position.set(0, 3.5, -6.92);
    scene.add(clockFrame);

    // 通知板/公告牌（右墙）
    const noticeBorder = new THREE.Mesh(
        new THREE.PlaneGeometry(1.0, 0.7),
        new THREE.MeshStandardMaterial({ color: 0x8B4513, roughness: 0.7 })
    );
    noticeBorder.position.set(6.9, 2.3, -3.5);
    noticeBorder.rotation.y = -Math.PI / 2;
    scene.add(noticeBorder);
    const noticeBoard = new THREE.Mesh(
        new THREE.PlaneGeometry(0.9, 0.6),
        new THREE.MeshStandardMaterial({ color: 0xf5f5dc, roughness: 0.5 })
    );
    noticeBoard.position.set(6.88, 2.3, -3.5);
    noticeBoard.rotation.y = -Math.PI / 2;
    scene.add(noticeBoard);

    // 墙面装饰角线（仅边角）
    const cornerTrim1 = new THREE.Mesh(
        new THREE.BoxGeometry(0.03, 3.5, 0.02),
        new THREE.MeshStandardMaterial({ color: 0xe0e0e2, roughness: 0.7 })
    );
    cornerTrim1.position.set(-6.5, 2.2, -6.95);
    scene.add(cornerTrim1);
    const cornerTrim2 = new THREE.Mesh(
        new THREE.BoxGeometry(0.03, 3.5, 0.02),
        new THREE.MeshStandardMaterial({ color: 0xe0e0e2, roughness: 0.7 })
    );
    cornerTrim2.position.set(6.5, 2.2, -6.95);
    scene.add(cornerTrim2);

    // 添加天花板灯光装置
    const ceilingLightGroup = new THREE.Group();
    ceilingLightGroup.position.set(0, 3.95, -2);
    
    // 灯具外框（方形灯罩）
    const lightFrame = new THREE.Mesh(
        new THREE.BoxGeometry(1.2, 0.08, 1.2),
        new THREE.MeshStandardMaterial({ color: 0xcccccc, roughness: 0.4, metalness: 0.6 })
    );
    ceilingLightGroup.add(lightFrame);
    
    // 发光面板
    const ceilingPlate = new THREE.Mesh(
        new THREE.PlaneGeometry(1.1, 1.1),
        new THREE.MeshStandardMaterial({ 
            color: 0xffffff, 
            emissive: 0xffffee,
            emissiveIntensity: 0.8,
            roughness: 0.3
        })
    );
    ceilingPlate.position.set(0, -0.05, 0);
    ceilingPlate.rotation.x = -Math.PI / 2;
    ceilingLightGroup.add(ceilingPlate);
    
    // 灯具边缘细节
    const edgeMaterial = new THREE.MeshStandardMaterial({ color: 0x888888, roughness: 0.5, metalness: 0.7 });
    const edge1 = new THREE.Mesh(new THREE.BoxGeometry(1.22, 0.02, 0.02), edgeMaterial);
    edge1.position.set(0, 0.05, -0.61);
    ceilingLightGroup.add(edge1);
    const edge2 = new THREE.Mesh(new THREE.BoxGeometry(1.22, 0.02, 0.02), edgeMaterial);
    edge2.position.set(0, 0.05, 0.61);
    ceilingLightGroup.add(edge2);
    const edge3 = new THREE.Mesh(new THREE.BoxGeometry(0.02, 0.02, 1.22), edgeMaterial);
    edge3.position.set(-0.61, 0.05, 0);
    ceilingLightGroup.add(edge3);
    const edge4 = new THREE.Mesh(new THREE.BoxGeometry(0.02, 0.02, 1.22), edgeMaterial);
    edge4.position.set(0.61, 0.05, 0);
    ceilingLightGroup.add(edge4);
    
    scene.add(ceilingLightGroup);

    // 补充灯光：柔和环境光 + 天花板聚光灯组 + 屏幕补光
    const ambient = new THREE.AmbientLight(0xffffff, 0.4);
    scene.add(ambient);

    // 主天花板灯光（向下照射）
    const ceilingSpot = new THREE.SpotLight(0xffffff, 2.5, 12, Math.PI / 4, 0.5, 1.5);
    ceilingSpot.position.set(0, 3.8, -2);
    ceilingSpot.target.position.set(0, 0, -2);
    ceilingSpot.castShadow = true;
    scene.add(ceilingSpot);
    scene.add(ceilingSpot.target);
    
    // 辅助天花板点光源（柔和填充光）
    const ceilingPoint = new THREE.PointLight(0xffffee, 1.0, 8);
    ceilingPoint.position.set(0, 3.8, -2);
    scene.add(ceilingPoint);

    const areaLight = new THREE.RectAreaLight(0xffffff, 2.0, 1.1, 1.1);
    areaLight.position.set(0, 3.9, -2);
    areaLight.lookAt(0, 0, -2);
    scene.add(areaLight);

    const wallFill = new THREE.SpotLight(0x87cefa, 0.4, 10, Math.PI / 5, 0.3);
    wallFill.position.set(0, 2.5, -3.2);
    wallFill.target.position.set(0, 1.8, -6.8);
    scene.add(wallFill);
    scene.add(wallFill.target);
}
