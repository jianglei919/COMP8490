import * as THREE from 'three';
import { VRButton } from 'three/addons/webxr/VRButton.js';
import { StepManager } from './StepManager.js';
import { createEnvironment } from './environment.js';
import { createVictim } from './victim.js';
import { createInteractionObjects } from './interactionObjects.js';
import { createInstructionPanel, updateInstructionText } from './ui.js';
import { setupDesktopControls } from './desktopControls.js';
import { setupVRControllers } from './vrControllers.js';
import { audioManager } from './audioManager.js';

/**
 * ============================================
 * 主应用程序
 * ============================================
 * 
 * 职责：
 * - 初始化 Three.js 场景、相机、渲染器
 * - 协调所有模块
 * - 管理动画循环
 * - 处理窗口调整大小
 * - 管理音效系统
 */

// 全局变量
let camera, scene, renderer;
let controls;
let instructionPanel;
let stepManager;
let interactableObjects = [];
let victimParts;

/**
 * 初始化应用程序
 */
function init() {
    // 创建场景
    scene = new THREE.Scene();
    scene.background = new THREE.Color(0xb0c4de); // 淡蓝色天空

    // 创建相机
    camera = new THREE.PerspectiveCamera(
        50,                                     // 视野角度
        window.innerWidth / window.innerHeight, // 宽高比
        0.1,                                    // 近裁剪面
        100                                     // 远裁剪面
    );
    camera.position.set(0, 3, 1.5); // 更高更近，俯视躺着的伤者

    // 添加照明
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.6);
    scene.add(ambientLight);

    const directionalLight = new THREE.DirectionalLight(0xffffff, 0.8);
    directionalLight.position.set(5, 10, 5);
    directionalLight.castShadow = true;
    scene.add(directionalLight);
    
    // 在场景上方添加点光源
    const pointLight = new THREE.PointLight(0xffffee, 0.5, 100);
    pointLight.position.set(0, 3.5, -2);
    scene.add(pointLight);

    // 创建支持 XR 的渲染器
    renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setPixelRatio(window.devicePixelRatio);
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.xr.enabled = true;
    document.body.appendChild(renderer.domElement);

    // 仅在支持 WebXR 时添加 VR 按钮
    if ('xr' in navigator) {
        navigator.xr.isSessionSupported('immersive-vr').then((supported) => {
            if (supported) {
                document.body.appendChild(VRButton.createButton(renderer));
            }
        });
    }

    // 初始化步骤管理器
    stepManager = new StepManager();

    // 创建环境（房间、墙壁、地板）
    createEnvironment(scene);
    
    // 创建伤者模型
    victimParts = createVictim(scene, interactableObjects);
    
    // 创建交互物体（安全标识、电话）
    createInteractionObjects(scene, interactableObjects);
    
    // 创建指令面板
    instructionPanel = createInstructionPanel(scene);

    // 设置桌面控制（鼠标/键盘）
    const desktopControls = setupDesktopControls(
        camera, 
        renderer, 
        interactableObjects, 
        stepManager, 
        updateUI
    );
    controls = desktopControls.controls;

    // 设置 VR 控制器
    setupVRControllers(renderer, scene, interactableObjects, stepManager, updateUI);

    // 启动背景环境音（柔和的氛围音）
    // 用户首次交互后会自动激活 AudioContext
    window.addEventListener('click', () => {
        audioManager.resume();
        audioManager.startBackgroundAmbience();
    }, { once: true });

    // 处理窗口大小调整
    window.addEventListener('resize', onWindowResize);

    // 启动动画循环
    renderer.setAnimationLoop(animate);

    // 更新初始指令
    updateUI();
}

/**
 * 更新 UI 显示
 */
function updateUI() {
    updateInstructionText(
        instructionPanel, 
        stepManager, 
        victimParts.shoulders, 
        victimParts.chest
    );
}

/**
 * 处理窗口大小调整
 */
function onWindowResize() {
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight);
}

/**
 * 动画循环
 */
function animate() {
    // 在桌面模式下更新控制器
    if (controls) {
        controls.update();
    }
    
    renderer.render(scene, camera);
}

// 初始化应用程序
init();
