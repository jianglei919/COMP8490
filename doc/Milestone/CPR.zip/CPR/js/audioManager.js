/**
 * ============================================
 * 音效管理器 - 使用 Web Audio API 生成音效
 * ============================================
 * 
 * 职责：
 * - 生成各种交互音效
 * - 管理背景环境音
 * - 控制音量和播放
 */

class AudioManager {
    constructor() {
        this.audioContext = new (window.AudioContext || window.webkitAudioContext)();
        this.masterVolume = 0.5; // 主音量
        this.backgroundSound = null;
        this.isBackgroundPlaying = false;
    }

    /**
     * 播放按钮点击音效
     */
    playButtonClick() {
        const now = this.audioContext.currentTime;
        const oscillator = this.audioContext.createOscillator();
        const gainNode = this.audioContext.createGain();

        oscillator.connect(gainNode);
        gainNode.connect(this.audioContext.destination);

        oscillator.frequency.setValueAtTime(800, now);
        oscillator.frequency.exponentialRampToValueAtTime(400, now + 0.1);
        
        gainNode.gain.setValueAtTime(this.masterVolume * 0.3, now);
        gainNode.gain.exponentialRampToValueAtTime(0.01, now + 0.15);

        oscillator.start(now);
        oscillator.stop(now + 0.15);
    }

    /**
     * 播放拍肩膀音效
     */
    playTapShoulder() {
        const now = this.audioContext.currentTime;
        
        // 创建两个音调模拟拍打声
        for (let i = 0; i < 2; i++) {
            const oscillator = this.audioContext.createOscillator();
            const gainNode = this.audioContext.createGain();
            const filter = this.audioContext.createBiquadFilter();

            oscillator.connect(filter);
            filter.connect(gainNode);
            gainNode.connect(this.audioContext.destination);

            oscillator.type = 'triangle';
            oscillator.frequency.setValueAtTime(150 - i * 20, now + i * 0.08);
            
            filter.type = 'lowpass';
            filter.frequency.setValueAtTime(300, now + i * 0.08);

            gainNode.gain.setValueAtTime(this.masterVolume * 0.4, now + i * 0.08);
            gainNode.gain.exponentialRampToValueAtTime(0.01, now + i * 0.08 + 0.12);

            oscillator.start(now + i * 0.08);
            oscillator.stop(now + i * 0.08 + 0.12);
        }
    }

    /**
     * 播放胸部按压音效
     */
    playChestCompression() {
        const now = this.audioContext.currentTime;
        
        // 低频"咚"声
        const oscillator = this.audioContext.createOscillator();
        const gainNode = this.audioContext.createGain();
        const filter = this.audioContext.createBiquadFilter();

        oscillator.connect(filter);
        filter.connect(gainNode);
        gainNode.connect(this.audioContext.destination);

        oscillator.type = 'sine';
        oscillator.frequency.setValueAtTime(80, now);
        oscillator.frequency.exponentialRampToValueAtTime(40, now + 0.15);
        
        filter.type = 'lowpass';
        filter.frequency.setValueAtTime(200, now);

        gainNode.gain.setValueAtTime(this.masterVolume * 0.5, now);
        gainNode.gain.exponentialRampToValueAtTime(0.01, now + 0.2);

        oscillator.start(now);
        oscillator.stop(now + 0.2);

        // 添加轻微的白噪声模拟按压质感
        const bufferSize = this.audioContext.sampleRate * 0.1;
        const buffer = this.audioContext.createBuffer(1, bufferSize, this.audioContext.sampleRate);
        const data = buffer.getChannelData(0);
        for (let i = 0; i < bufferSize; i++) {
            data[i] = (Math.random() * 2 - 1) * 0.1;
        }
        
        const noise = this.audioContext.createBufferSource();
        const noiseGain = this.audioContext.createGain();
        const noiseFilter = this.audioContext.createBiquadFilter();
        
        noise.buffer = buffer;
        noise.connect(noiseFilter);
        noiseFilter.connect(noiseGain);
        noiseGain.connect(this.audioContext.destination);
        
        noiseFilter.type = 'bandpass';
        noiseFilter.frequency.setValueAtTime(150, now);
        
        noiseGain.gain.setValueAtTime(this.masterVolume * 0.15, now);
        noiseGain.gain.exponentialRampToValueAtTime(0.01, now + 0.1);
        
        noise.start(now);
        noise.stop(now + 0.1);
    }

    /**
     * 播放步骤完成音效
     */
    playStepComplete() {
        const now = this.audioContext.currentTime;
        const notes = [523.25, 659.25, 783.99]; // C5, E5, G5 和弦

        notes.forEach((freq, index) => {
            const oscillator = this.audioContext.createOscillator();
            const gainNode = this.audioContext.createGain();

            oscillator.connect(gainNode);
            gainNode.connect(this.audioContext.destination);

            oscillator.frequency.setValueAtTime(freq, now);
            oscillator.type = 'sine';

            gainNode.gain.setValueAtTime(0, now);
            gainNode.gain.linearRampToValueAtTime(this.masterVolume * 0.2, now + 0.05);
            gainNode.gain.exponentialRampToValueAtTime(0.01, now + 0.4);

            oscillator.start(now);
            oscillator.stop(now + 0.4);
        });
    }

    /**
     * 播放紧急电话音效
     */
    playEmergencyCall() {
        const now = this.audioContext.currentTime;
        
        // 模拟电话拨号音
        for (let i = 0; i < 3; i++) {
            const oscillator = this.audioContext.createOscillator();
            const gainNode = this.audioContext.createGain();

            oscillator.connect(gainNode);
            gainNode.connect(this.audioContext.destination);

            oscillator.frequency.setValueAtTime(850, now + i * 0.25);
            oscillator.type = 'sine';

            gainNode.gain.setValueAtTime(this.masterVolume * 0.25, now + i * 0.25);
            gainNode.gain.exponentialRampToValueAtTime(0.01, now + i * 0.25 + 0.15);

            oscillator.start(now + i * 0.25);
            oscillator.stop(now + i * 0.25 + 0.15);
        }
    }

    /**
     * 开始播放环境背景音（柔和的低频嗡嗡声）
     */
    startBackgroundAmbience() {
        if (this.isBackgroundPlaying) return;

        const now = this.audioContext.currentTime;
        
        // 创建低频背景氛围音
        const oscillator1 = this.audioContext.createOscillator();
        const oscillator2 = this.audioContext.createOscillator();
        const gainNode = this.audioContext.createGain();
        const filter = this.audioContext.createBiquadFilter();

        oscillator1.connect(filter);
        oscillator2.connect(filter);
        filter.connect(gainNode);
        gainNode.connect(this.audioContext.destination);

        oscillator1.type = 'sine';
        oscillator2.type = 'sine';
        oscillator1.frequency.setValueAtTime(55, now); // A1
        oscillator2.frequency.setValueAtTime(82.5, now); // E2
        
        filter.type = 'lowpass';
        filter.frequency.setValueAtTime(150, now);
        filter.Q.setValueAtTime(0.5, now);

        gainNode.gain.setValueAtTime(0, now);
        gainNode.gain.linearRampToValueAtTime(this.masterVolume * 0.05, now + 2);

        oscillator1.start(now);
        oscillator2.start(now);

        this.backgroundSound = { oscillator1, oscillator2, gainNode };
        this.isBackgroundPlaying = true;
    }

    /**
     * 停止背景音
     */
    stopBackgroundAmbience() {
        if (!this.isBackgroundPlaying || !this.backgroundSound) return;

        const now = this.audioContext.currentTime;
        this.backgroundSound.gainNode.gain.linearRampToValueAtTime(0, now + 1);
        
        setTimeout(() => {
            if (this.backgroundSound) {
                this.backgroundSound.oscillator1.stop();
                this.backgroundSound.oscillator2.stop();
                this.backgroundSound = null;
                this.isBackgroundPlaying = false;
            }
        }, 1000);
    }

    /**
     * 设置主音量
     * @param {number} volume - 音量值 (0.0 到 1.0)
     */
    setMasterVolume(volume) {
        this.masterVolume = Math.max(0, Math.min(1, volume));
    }

    /**
     * 恢复 AudioContext（用户交互后激活）
     */
    resume() {
        if (this.audioContext.state === 'suspended') {
            this.audioContext.resume();
        }
    }
}

// 创建单例实例
const audioManager = new AudioManager();

export { audioManager };
