import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { Shape, ShapeGeometry } from 'three';

// ============================================
// INTERACTION OBJECTS - 创建交互物体
// ============================================
export function createInteractionObjects(scene, interactableObjects) {
    const loader = new GLTFLoader();

    // Safety sign: prefer models/sign.glb if present; else use stylized geometry
    const signGroup = new THREE.Group();
    signGroup.position.set(-3, 1.8, -6.8);
    signGroup.userData.type = "CHECK_SAFETY";
    scene.add(signGroup);

    let signBoard;
    loader.load(
        'models/sign.glb',
        (gltf) => {
            const signModel = gltf.scene;
            signModel.userData.type = "CHECK_SAFETY";
            signGroup.add(signModel);
            signBoard = signModel;
            interactableObjects.push(signBoard);
        },
        undefined,
        () => {
            // 圆形黄色按钮（去掉对号）
            const circleGeom = new THREE.CircleGeometry(0.35, 48);
            const circleMat = new THREE.MeshPhysicalMaterial({
                color: 0xffe000,
                emissive: 0xffd000,
                emissiveIntensity: 0.5,
                roughness: 0.55,
                clearcoat: 0.25,
                clearcoatRoughness: 0.35
            });
            const circle = new THREE.Mesh(circleGeom, circleMat);
            circle.position.z = 0.04;
            circle.userData.type = "CHECK_SAFETY";

            // 仅保留圆形按钮，不使用背板
            const group = new THREE.Group();
            group.add(circle);
            group.userData.type = "CHECK_SAFETY";
            signGroup.add(group);
            signBoard = circle;

            // 柔光效果（居中对齐圆形按钮，添加到内层group确保居中）
            const glow = new THREE.PointLight(0xffd000, 0.7, 1.5);
            glow.position.set(0, 0, 0.08);
            group.add(glow);

            interactableObjects.push(signBoard);
        }
    );
    
    // Emergency phone: prefer models/phone.glb; else stylized geometry
    const phoneGroup = new THREE.Group();
    phoneGroup.position.set(3, 1.8, -6.8);
    phoneGroup.userData.type = "CALL_EMERGENCY";
    scene.add(phoneGroup);

    let phoneButton;
    loader.load(
        'models/phone.glb',
        (gltf) => {
            const phoneModel = gltf.scene;
            phoneModel.userData.type = "CALL_EMERGENCY";
            phoneGroup.add(phoneModel);
            phoneButton = phoneModel;
            interactableObjects.push(phoneButton);
        },
        undefined,
        () => {
            // 背板（圆角矩形）
            const roundedRect = (w, h, r) => {
                const shape = new Shape();
                const x = -w / 2, y = -h / 2;
                shape.moveTo(x + r, y);
                shape.lineTo(x + w - r, y);
                shape.quadraticCurveTo(x + w, y, x + w, y + r);
                shape.lineTo(x + w, y + h - r);
                shape.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
                shape.lineTo(x + r, y + h);
                shape.quadraticCurveTo(x, y + h, x, y + h - r);
                shape.lineTo(x, y + r);
                shape.quadraticCurveTo(x, y, x + r, y);
                return shape;
            };

            const backGeom = new ShapeGeometry(roundedRect(0.2, 0.38, 0.03));
            const backMat = new THREE.MeshPhysicalMaterial({ color: 0x990000, emissive: 0x550000, emissiveIntensity: 0.2, roughness: 0.6, metalness: 0.2, clearcoat: 0.3 });
            const backPlate = new THREE.Mesh(backGeom, backMat);
            backPlate.position.z = 0.02;
            phoneGroup.add(backPlate);

            // 红色按钮（略微圆角的凸起圆柱）
            const btnMat = new THREE.MeshStandardMaterial({ color: 0xff2222, emissive: 0xaa0000, emissiveIntensity: 0.5, roughness: 0.4 });
            const button = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, 0.03, 32), btnMat);
            button.rotation.x = Math.PI / 2;
            button.position.set(0, 0.06, 0.06);
            button.userData.type = "CALL_EMERGENCY";
            phoneGroup.add(button);

            // 小屏幕（玻璃质感）
            const screen = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.12, 0.01), new THREE.MeshPhysicalMaterial({ color: 0x111111, roughness: 0.1, transmission: 0.0, reflectivity: 0.6 }));
            screen.position.set(0, -0.06, 0.055);
            phoneGroup.add(screen);

            // 白色十字标志
            const crossMat = new THREE.MeshBasicMaterial({ color: 0xffffff });
            const crossV = new THREE.Mesh(new THREE.BoxGeometry(0.02, 0.08, 0.002), crossMat);
            crossV.position.set(0, -0.06, 0.06);
            phoneGroup.add(crossV);
            const crossH = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.02, 0.002), crossMat);
            crossH.position.set(0, -0.06, 0.06);
            phoneGroup.add(crossH);

            // 收紧光晕，减少扩散
            const glow = new THREE.PointLight(0xff4444, 0.5, 0.6);
            glow.position.set(0, 0.06, 0.08);
            phoneGroup.add(glow);

            phoneButton = button;
            interactableObjects.push(phoneButton);
        }
    );
    
    return {
        safetyButton: signBoard,
        phoneButton: phoneButton
    };
}
