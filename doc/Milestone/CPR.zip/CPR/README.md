# VR CPR 训练系统原型

基于 WebXR 的浏览器 VR 心肺复苏（CPR）训练原型，使用 Three.js 构建。

## 功能特性

- 基于 WebXR 的浏览器 VR 体验
- 4 步 CPR 训练流程：
  1. 检查现场安全
  2. 检查伤者反应
  3. 拨打急救电话
  4. 执行胸外按压
- 支持鼠标点击交互（桌面模式）
- 支持 VR 手柄交互（VR 模式）
- 实时进度跟踪
- 完成总结报告

## 系统要求

### 桌面模式（推荐用于测试）
- 现代浏览器（Chrome、Firefox、Edge、Safari）
- 鼠标和键盘

### VR 模式
- 支持 WebXR 的浏览器：
  - Meta Quest 浏览器（Quest 1, 2, 3, Pro）
  - Chrome/Edge（需启用 WebXR）
  - Firefox Reality
- VR 头显和手柄

## 运行应用

### 本地开发

1. 需要通过 HTTP/HTTPS 服务文件（WebXR 要求）：

   **方式 1：使用 Python**
   ```bash
   # Python 3
   python3 -m http.server 8000
   
   # Python 2
   python -m SimpleHTTPServer 8000
   ```

   **方式 2：使用 Node.js (http-server)**
   ```bash
   npx http-server -p 8000
   ```

   **方式 3：使用 VS Code Live Server 扩展**
   - 安装 "Live Server" 扩展
   - 右键点击 `index.html` 选择 "Open with Live Server"

2. 打开浏览器访问：
   ```
   http://localhost:8000
   ```

3. 在 VR 头显上测试：
   - 确保开发机器和 VR 头显在同一网络
   - 查找机器的本地 IP 地址（例如：192.168.1.100）
   - 在 VR 头显浏览器中访问：`http://你的IP:8000`

4. 点击 "ENTER VR" 按钮进入沉浸式体验（可选）

## 使用方法

### 桌面模式（无需 VR 设备）
1. **旋转视角**：左键拖拽鼠标
2. **缩放**：滚动鼠标滚轮
3. **平移视角**：右键拖拽鼠标
4. **交互**：点击物体完成步骤
5. **按步骤操作**：
   - 步骤 1：点击墙上的黄色安全标识
   - 步骤 2：点击伤者肩部的橙色区域
   - 步骤 3：点击墙上的红色急救电话
   - 步骤 4：连续点击伤者胸部红色标记 5 次

### VR 模式
1. **进入 VR**：点击 "ENTER VR" 按钮
2. **阅读指令**：查看前方浮动的指令面板
3. **交互**：用手柄指向高亮物体并按触发器按钮
4. **完成步骤**：按照提示完成 4 个步骤
5. **查看总结**：完成后查看训练总结

## 项目结构

```
CPR/
├── index.html              # HTML 入口页面
├── README.md               # 项目说明（本文件）
├── PROJECT_STRUCTURE.md    # 详细的项目结构文档
│
└── js/                     # JavaScript 模块目录
    ├── main.js             # 主应用入口
    ├── StepManager.js      # 步骤管理器
    ├── environment.js      # 环境场景
    ├── victim.js           # 伤者模型
    ├── interactionObjects.js   # 交互物体
    ├── ui.js               # UI 界面
    ├── desktopControls.js  # 桌面控制
    └── vrControllers.js    # VR 控制器
```

详细的模块说明请查看 [PROJECT_STRUCTURE.md](PROJECT_STRUCTURE.md)

## 技术细节

- **框架**：Three.js v0.160.0（通过 CDN 加载）
- **VR API**：WebXR Device API
- **渲染**：WebGL
- **控制器**：支持 XR 控制器，基于射线的交互
- **无需后端**：完全客户端应用

## 代码架构

### StepManager 类
管理训练流程：
- 存储步骤定义和进度
- 跟踪当前步骤
- 验证完成状态
- 生成训练总结

### 主要组件
- **场景设置**：相机、照明、启用 XR 的渲染器
- **环境**：地板和墙壁提供上下文
- **伤者模型**：具有交互区域的 3D 人体模型
- **交互物体**：安全标识、急救电话
- **UI 系统**：基于 Canvas 的文本面板显示指令
- **控制器系统**：VR 手柄射线投射 / 鼠标射线投射

### 交互流程
1. 用户将手柄/鼠标指向物体
2. 射线投射检测相交
3. 触发器/鼠标点击检查物体是否匹配当前步骤
4. 步骤完成更新进度
5. 指令面板更新到下一步骤

## 自定义

要修改训练步骤，编辑 `js/StepManager.js` 中的 `steps` 数组：

```javascript
this.steps = [
    { 
        id: "YOUR_STEP_ID", 
        text: "显示给用户的指令文本", 
        type: "INTERACTION_TYPE",
        completed: false
    },
    // 添加更多步骤...
];
```

## 浏览器兼容性

- ✅ Meta Quest 浏览器（推荐用于 VR）
- ✅ Chrome 79+（需启用 WebXR 标志）
- ✅ Edge 79+（需启用 WebXR 标志）
- ✅ Firefox Reality
- ✅ 所有现代浏览器（桌面模式）
- ❌ Safari（不支持 WebXR，但桌面模式可用）

## MVP 限制

这是一个最小化原型，存在以下有意的限制：
- 简化的图形和模型
- 基础交互检测（无精确动作追踪）
- 无触觉反馈
- 无按压深度测量
- 无按压时机/节奏反馈
- 仅单一训练场景
- 无数据持久化或分析

## 未来增强功能

生产版本的潜在改进：
- 真实的 3D 人体和环境模型
- 使用手柄位置精确追踪按压深度
- 按压速率的时机反馈（100-120 次/分钟）
- 多种场景（儿童 CPR、AED 使用等）
- 语音指导和音频反馈
- 性能指标和评分系统
- 进度保存和用户账户
- 多人协作训练

## 故障排除

**"ENTER VR" 按钮不出现：**
- 确保使用 HTTPS 或 localhost
- 检查浏览器 WebXR 兼容性
- 验证 VR 头显已连接
- 注意：桌面模式不需要此按钮

**无法与物体交互：**
- 确保按下手柄的触发器按钮 / 鼠标左键
- 检查是否直接指向彩色物体
- 确保手柄被正确追踪

**性能问题：**
- 关闭 VR 头显上的其他应用
- 尝试不同的浏览器
- 必要时降低场景复杂度

## 许可证

这是一个用于教育目的的原型。

## 致谢

使用 Three.js 和 WebXR Device API 构建。
