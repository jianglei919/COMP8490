import * as THREE from 'three';
import { VRButton } from 'three/addons/webxr/VRButton.js';
import { XRControllerModelFactory } from 'three/addons/webxr/XRControllerModelFactory.js';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { FontLoader } from 'three/addons/loaders/FontLoader.js';
import { TextGeometry } from 'three/addons/geometries/TextGeometry.js';

// ============================================
// STEP MANAGER
// ============================================
class StepManager {
    constructor() {
        this.steps = [
            { 
                id: "CHECK_SAFETY", 
                text: "步骤 1：检查现场是否安全\n点击墙上的黄色安全标识", 
                type: "CHECK_SAFETY",
                completed: false
            },
            { 
                id: "CHECK_RESPONSIVENESS", 
                text: "步骤 2：拍打伤者肩膀并呼喊\n点击伤者肩部的橙色区域", 
                type: "TAP_SHOULDERS",
                completed: false
            },
            { 
                id: "CALL_EMERGENCY", 
                text: "步骤 3：拨打急救电话\n点击墙上的红色急救电话", 
                type: "CALL_EMERGENCY",
                completed: false
            },
            { 
                id: "START_COMPRESSIONS", 
                text: "步骤 4：开始胸外按压\n连续点击伤者胸部的红色标记 5 次", 
                type: "CHEST_COMPRESSIONS",
                completed: false,
                compressionCount: 0,
                requiredCompressions: 5
            }
        ];
        this.currentIndex = 0;
    }

    getCurrentStep() {
        return this.steps[this.currentIndex];
    }

    completeCurrentStep() {
        if (!this.isFinished()) {
            this.steps[this.currentIndex].completed = true;
            this.currentIndex++;
            return true;
        }
        return false;
    }

    isFinished() {
        return this.currentIndex >= this.steps.length;
    }

    getSummary() {
        let summary = "训练完成！\n\n";
        this.steps.forEach((step, index) => {
            const stepName = [
                "检查现场安全",
                "检查伤者反应", 
                "拨打急救电话",
                "胸外按压"
            ][index];
            summary += `步骤 ${index + 1}：${stepName} - ${step.completed ? '✓ 已完成' : '✗ 未完成'}\n`;
        });
        return summary;
    }
}

// ============================================
// SCENE SETUP
// ============================================
let camera, scene, renderer;
let controller1, controller2;
let controllerGrip1, controllerGrip2;
let raycaster;
let controls; // OrbitControls for desktop
let mouse, hoveredObject;

// Scene objects
let victim, victimChest, victimShoulders;
let safetyButton, phoneButton;
let instructionPanel, instructionText;

// Step management
let stepManager;
let interactableObjects = [];

function init() {
    // Create scene
    scene = new THREE.Scene();
    scene.background = new THREE.Color(0xb0c4de); // Light steel blue

    // Create camera
    camera = new THREE.PerspectiveCamera(
        50,
        window.innerWidth / window.innerHeight,
        0.1,
        100
    );
    camera.position.set(0, 3, 1.5); // Higher and closer to see lying victim

    // Add lighting
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.6);
    scene.add(ambientLight);

    const directionalLight = new THREE.DirectionalLight(0xffffff, 0.8);
    directionalLight.position.set(5, 10, 5);
    directionalLight.castShadow = true;
    scene.add(directionalLight);
    
    // Add a point light above the scene
    const pointLight = new THREE.PointLight(0xffffee, 0.5, 100);
    pointLight.position.set(0, 3.5, -2);
    scene.add(pointLight);

    // Create renderer with XR support
    renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setPixelRatio(window.devicePixelRatio);
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.xr.enabled = true;
    document.body.appendChild(renderer.domElement);

    // Add VR button only if WebXR is supported
    if ('xr' in navigator) {
        navigator.xr.isSessionSupported('immersive-vr').then((supported) => {
            if (supported) {
                document.body.appendChild(VRButton.createButton(renderer));
            }
        });
    }

    // Initialize step manager
    stepManager = new StepManager();

    // Create environment
    createEnvironment();
    createVictim();
    createInteractionObjects();
    createInstructionPanel();

    // Setup VR controllers
    setupControllers();

    // Raycaster for interaction
    raycaster = new THREE.Raycaster();

    // Setup desktop controls
    setupDesktopControls();

    // Handle window resize
    window.addEventListener('resize', onWindowResize);

    // Start animation loop
    renderer.setAnimationLoop(animate);

    // Update initial instruction
    updateInstructionText();
}

function createEnvironment() {
    // Floor with more realistic appearance
    const floorGeometry = new THREE.PlaneGeometry(15, 15);
    const floorMaterial = new THREE.MeshStandardMaterial({ 
        color: 0xcccccc,
        roughness: 0.8,
        metalness: 0.2
    });
    const floor = new THREE.Mesh(floorGeometry, floorMaterial);
    floor.rotation.x = -Math.PI / 2;
    floor.receiveShadow = true;
    scene.add(floor);

    // Add grid for better depth perception
    const gridHelper = new THREE.GridHelper(15, 30, 0x888888, 0x444444);
    gridHelper.position.y = 0.01;
    scene.add(gridHelper);

    // Room walls
    const wallMaterial = new THREE.MeshStandardMaterial({ 
        color: 0xe8e8e8,
        roughness: 0.9
    });
    
    // Back wall
    const backWall = new THREE.Mesh(
        new THREE.PlaneGeometry(15, 4),
        wallMaterial
    );
    backWall.position.set(0, 2, -7);
    scene.add(backWall);
    
    // Left wall
    const leftWall = new THREE.Mesh(
        new THREE.PlaneGeometry(15, 4),
        wallMaterial
    );
    leftWall.position.set(-7, 2, 0);
    leftWall.rotation.y = Math.PI / 2;
    scene.add(leftWall);
    
    // Right wall
    const rightWall = new THREE.Mesh(
        new THREE.PlaneGeometry(15, 4),
        wallMaterial
    );
    rightWall.position.set(7, 2, 0);
    rightWall.rotation.y = -Math.PI / 2;
    scene.add(rightWall);

    // Add ceiling light representation
    const ceilingLight = new THREE.Mesh(
        new THREE.PlaneGeometry(2, 2),
        new THREE.MeshBasicMaterial({ color: 0xffffee, side: THREE.DoubleSide })
    );
    ceilingLight.position.set(0, 3.99, -2);
    ceilingLight.rotation.x = Math.PI / 2;
    scene.add(ceilingLight);
}

function createVictim() {
    // Create a more realistic human-like victim lying on the ground
    const victimGroup = new THREE.Group();
    
    // Body (torso) - lying flat
    const torsoGeometry = new THREE.CapsuleGeometry(0.25, 0.7, 8, 16);
    const skinMaterial = new THREE.MeshStandardMaterial({ 
        color: 0xffdbac,
        roughness: 0.8
    });
    const torso = new THREE.Mesh(torsoGeometry, skinMaterial);
    torso.position.set(0, 0.15, 0);
    torso.rotation.z = Math.PI / 2; // Rotate to lie flat
    victimGroup.add(torso);
    
    // Head - lying flat
    const headGeometry = new THREE.SphereGeometry(0.18, 32, 32);
    const head = new THREE.Mesh(headGeometry, skinMaterial);
    head.position.set(0, 0.18, 0.55);
    head.scale.set(1, 0.9, 1); // Slightly flattened
    victimGroup.add(head);
    
    // Neck
    const neckGeometry = new THREE.CylinderGeometry(0.09, 0.11, 0.12);
    const neck = new THREE.Mesh(neckGeometry, skinMaterial);
    neck.position.set(0, 0.15, 0.42);
    neck.rotation.x = Math.PI / 2;
    victimGroup.add(neck);
    
    // Arms - lying beside body
    const armMaterial = new THREE.MeshStandardMaterial({ 
        color: 0x4488ff,
        roughness: 0.7
    });
    
    // Left arm
    const armGeometry = new THREE.CapsuleGeometry(0.07, 0.45, 8, 16);
    const leftArm = new THREE.Mesh(armGeometry, armMaterial);
    leftArm.position.set(-0.35, 0.1, 0);
    leftArm.rotation.z = Math.PI / 2;
    leftArm.rotation.y = Math.PI / 8;
    victimGroup.add(leftArm);
    
    // Right arm
    const rightArm = new THREE.Mesh(armGeometry, armMaterial);
    rightArm.position.set(0.35, 0.1, 0);
    rightArm.rotation.z = Math.PI / 2;
    rightArm.rotation.y = -Math.PI / 8;
    victimGroup.add(rightArm);
    
    // Legs - lying flat
    const legMaterial = new THREE.MeshStandardMaterial({ 
        color: 0x333333,
        roughness: 0.8
    });
    
    const legGeometry = new THREE.CapsuleGeometry(0.11, 0.65, 8, 16);
    
    // Left leg
    const leftLeg = new THREE.Mesh(legGeometry, legMaterial);
    leftLeg.position.set(-0.12, 0.11, -0.45);
    leftLeg.rotation.z = Math.PI / 2;
    victimGroup.add(leftLeg);
    
    // Right leg
    const rightLeg = new THREE.Mesh(legGeometry, legMaterial);
    rightLeg.position.set(0.12, 0.11, -0.45);
    rightLeg.rotation.z = Math.PI / 2;
    victimGroup.add(rightLeg);
    
    // Interactive markers
    // Shoulders marker (for step 2) - highly visible
    const shouldersGeometry = new THREE.BoxGeometry(0.55, 0.22, 0.28);
    const shouldersMaterial = new THREE.MeshStandardMaterial({ 
        color: 0xff6600,
        emissive: 0xff6600,
        emissiveIntensity: 0.8,
        transparent: true,
        opacity: 0.0  // Invisible until needed
    });
    victimShoulders = new THREE.Mesh(shouldersGeometry, shouldersMaterial);
    victimShoulders.position.set(0, 0.26, 0.25);
    victimShoulders.userData.type = "TAP_SHOULDERS";
    victimGroup.add(victimShoulders);
    
    // Chest marker (for step 4) - CPR position, very visible
    const chestGeometry = new THREE.CylinderGeometry(0.2, 0.2, 0.12, 32);
    const chestMaterial = new THREE.MeshStandardMaterial({ 
        color: 0xff0000,
        emissive: 0xff0000,
        emissiveIntensity: 1.0,
        transparent: true,
        opacity: 0.0  // Invisible until needed
    });
    victimChest = new THREE.Mesh(chestGeometry, chestMaterial);
    victimChest.position.set(0, 0.28, -0.05); // Center of chest
    victimChest.userData.type = "CHEST_COMPRESSIONS";
    victimGroup.add(victimChest);
    
    // Add a blue emergency mat under the victim
    const matGeometry = new THREE.PlaneGeometry(1.8, 2.5);
    const matMaterial = new THREE.MeshStandardMaterial({ 
        color: 0x6666ff,
        roughness: 0.9
    });
    const mat = new THREE.Mesh(matGeometry, matMaterial);
    mat.rotation.x = -Math.PI / 2;
    mat.position.y = 0.01;
    victimGroup.add(mat);
    
    victimGroup.position.set(0, 0, -2);
    scene.add(victimGroup);
    
    victim = victimGroup;
    
    // Add to interactable objects
    interactableObjects.push(victimShoulders, victimChest);
}

function createInteractionObjects() {
    // Safety check sign (Step 1) - A warning sign on the wall
    const signGroup = new THREE.Group();
    
    // Sign board
    const signGeometry = new THREE.BoxGeometry(0.5, 0.5, 0.05);
    const signMaterial = new THREE.MeshStandardMaterial({ 
        color: 0xffff00,
        emissive: 0xffff00,
        emissiveIntensity: 0.3
    });
    const signBoard = new THREE.Mesh(signGeometry, signMaterial);
    signGroup.add(signBoard);
    
    // Green check symbol
    const checkMaterial = new THREE.MeshStandardMaterial({ 
        color: 0x00ff00,
        emissive: 0x00ff00,
        emissiveIntensity: 0.5
    });
    const checkGeometry = new THREE.BoxGeometry(0.3, 0.05, 0.02);
    const checkPart1 = new THREE.Mesh(checkGeometry, checkMaterial);
    checkPart1.position.set(0, 0, 0.04);
    checkPart1.rotation.z = Math.PI / 4;
    signGroup.add(checkPart1);
    
    const checkPart2 = new THREE.Mesh(
        new THREE.BoxGeometry(0.15, 0.05, 0.02),
        checkMaterial
    );
    checkPart2.position.set(-0.08, -0.08, 0.04);
    checkPart2.rotation.z = -Math.PI / 4;
    signGroup.add(checkPart2);
    
    signGroup.position.set(-3, 1.8, -6.8);
    signGroup.userData.type = "CHECK_SAFETY";
    scene.add(signGroup);
    safetyButton = signBoard;
    safetyButton.userData.type = "CHECK_SAFETY";
    interactableObjects.push(safetyButton);
    
    // Emergency phone (Step 3) - Wall-mounted phone
    const phoneGroup = new THREE.Group();
    
    // Phone body
    const phoneBodyGeometry = new THREE.BoxGeometry(0.15, 0.35, 0.08);
    const phoneBodyMaterial = new THREE.MeshStandardMaterial({ 
        color: 0xcc0000,
        emissive: 0xff0000,
        emissiveIntensity: 0.4,
        metalness: 0.3,
        roughness: 0.6
    });
    const phoneBody = new THREE.Mesh(phoneBodyGeometry, phoneBodyMaterial);
    phoneGroup.add(phoneBody);
    
    // Phone screen
    const screenGeometry = new THREE.BoxGeometry(0.12, 0.2, 0.02);
    const screenMaterial = new THREE.MeshStandardMaterial({ 
        color: 0x000000,
        emissive: 0xff0000,
        emissiveIntensity: 0.2
    });
    const screen = new THREE.Mesh(screenGeometry, screenMaterial);
    screen.position.set(0, 0.05, 0.05);
    phoneGroup.add(screen);
    
    // Emergency cross symbol
    const crossMaterial = new THREE.MeshBasicMaterial({ color: 0xffffff });
    const crossV = new THREE.Mesh(
        new THREE.BoxGeometry(0.02, 0.1, 0.01),
        crossMaterial
    );
    crossV.position.set(0, 0.05, 0.06);
    phoneGroup.add(crossV);
    
    const crossH = new THREE.Mesh(
        new THREE.BoxGeometry(0.1, 0.02, 0.01),
        crossMaterial
    );
    crossH.position.set(0, 0.05, 0.06);
    phoneGroup.add(crossH);
    
    phoneGroup.position.set(3, 1.8, -6.8);
    phoneGroup.userData.type = "CALL_EMERGENCY";
    scene.add(phoneGroup);
    phoneButton = phoneBody;
    phoneButton.userData.type = "CALL_EMERGENCY";
    interactableObjects.push(phoneButton);
}

function createInstructionPanel() {
    // Create a canvas for text rendering
    const canvas = document.createElement('canvas');
    canvas.width = 1024;
    canvas.height = 512;
    const context = canvas.getContext('2d');
    
    // Create texture from canvas
    const texture = new THREE.CanvasTexture(canvas);
    
    // Create panel mesh
    const panelGeometry = new THREE.PlaneGeometry(2, 1);
    const panelMaterial = new THREE.MeshBasicMaterial({ 
        map: texture,
        transparent: true,
        side: THREE.DoubleSide
    });
    instructionPanel = new THREE.Mesh(panelGeometry, panelMaterial);
    instructionPanel.position.set(0, 2, -1.5);
    scene.add(instructionPanel);
    
    // Store canvas for updates
    instructionPanel.userData.canvas = canvas;
    instructionPanel.userData.context = context;
    instructionPanel.userData.texture = texture;
}

function getCurrentStepAndUpdateVisuals() {
    const currentStep = stepManager.getCurrentStep();
    
    // Hide all markers first
    if (victimShoulders) victimShoulders.material.opacity = 0.0;
    if (victimChest) victimChest.material.opacity = 0.0;
    
    // Show only the marker for current step with high visibility
    if (!stepManager.isFinished()) {
        if (currentStep.type === "TAP_SHOULDERS" && victimShoulders) {
            victimShoulders.material.opacity = 0.85;
        } else if (currentStep.type === "CHEST_COMPRESSIONS" && victimChest) {
            victimChest.material.opacity = 0.9;
        }
    }
}

function updateInstructionText() {
    const canvas = instructionPanel.userData.canvas;
    const context = instructionPanel.userData.context;
    const texture = instructionPanel.userData.texture;
    
    // Clear canvas
    context.fillStyle = 'rgba(0, 0, 0, 0.8)';
    context.fillRect(0, 0, canvas.width, canvas.height);
    
    // Draw border
    context.strokeStyle = '#00ffff';
    context.lineWidth = 10;
    context.strokeRect(10, 10, canvas.width - 20, canvas.height - 20);
    
    // Draw text
    context.fillStyle = '#ffffff';
    context.font = 'bold 48px Arial';
    context.textAlign = 'center';
    
    let text;
    if (stepManager.isFinished()) {
        text = stepManager.getSummary();
        context.fillStyle = '#00ff00';
        context.font = 'bold 56px Arial';
    } else {
        text = stepManager.getCurrentStep().text;
        
        // Show compression count for step 4
        const currentStep = stepManager.getCurrentStep();
        if (currentStep.type === "CHEST_COMPRESSIONS") {
            text += `\n\n按压次数：${currentStep.compressionCount}/${currentStep.requiredCompressions}`;
        }
    }
    
    // Draw multi-line text
    const lines = text.split('\n');
    const lineHeight = 60;
    const startY = (canvas.height - (lines.length * lineHeight)) / 2 + 40;
    
    lines.forEach((line, index) => {
        context.fillText(line, canvas.width / 2, startY + (index * lineHeight));
    });
    
    texture.needsUpdate = true;
    
    // Update visual markers
    getCurrentStepAndUpdateVisuals();
}

function setupControllers() {
    const controllerModelFactory = new XRControllerModelFactory();

    // Controller 1
    controller1 = renderer.xr.getController(0);
    controller1.addEventListener('selectstart', onSelectStart);
    controller1.addEventListener('selectend', onSelectEnd);
    scene.add(controller1);

    controllerGrip1 = renderer.xr.getControllerGrip(0);
    controllerGrip1.add(controllerModelFactory.createControllerModel(controllerGrip1));
    scene.add(controllerGrip1);

    // Controller 2
    controller2 = renderer.xr.getController(1);
    controller2.addEventListener('selectstart', onSelectStart);
    controller2.addEventListener('selectend', onSelectEnd);
    scene.add(controller2);

    controllerGrip2 = renderer.xr.getControllerGrip(1);
    controllerGrip2.add(controllerModelFactory.createControllerModel(controllerGrip2));
    scene.add(controllerGrip2);

    // Add visual ray to controllers
    const geometry = new THREE.BufferGeometry().setFromPoints([
        new THREE.Vector3(0, 0, 0),
        new THREE.Vector3(0, 0, -1)
    ]);
    const material = new THREE.LineBasicMaterial({ color: 0x00ffff });
    
    const line1 = new THREE.Line(geometry, material);
    line1.scale.z = 5;
    controller1.add(line1.clone());
    
    const line2 = new THREE.Line(geometry, material);
    line2.scale.z = 5;
    controller2.add(line2.clone());
}

function onSelectStart(event) {
    const controller = event.target;
    handleInteraction(controller);
}

function onSelectEnd(event) {
    // Optional: handle release if needed
}

function handleInteraction(controller) {
    if (stepManager.isFinished()) {
        return;
    }

    // Create a ray from the controller
    const tempMatrix = new THREE.Matrix4();
    tempMatrix.identity().extractRotation(controller.matrixWorld);
    
    raycaster.ray.origin.setFromMatrixPosition(controller.matrixWorld);
    raycaster.ray.direction.set(0, 0, -1).applyMatrix4(tempMatrix);

    // Check for intersections with interactable objects
    const intersects = raycaster.intersectObjects(interactableObjects, true);

    if (intersects.length > 0) {
        const hitObject = intersects[0].object;
        const currentStep = stepManager.getCurrentStep();

        // Check if the hit object matches the current step type
        if (hitObject.userData.type === currentStep.type) {
            // Special handling for compressions
            if (currentStep.type === "CHEST_COMPRESSIONS") {
                currentStep.compressionCount++;
                updateInstructionText();
                
                // Visual feedback
                hitObject.material.emissive = new THREE.Color(0xff0000);
                setTimeout(() => {
                    hitObject.material.emissive = new THREE.Color(0x000000);
                }, 100);
                
                if (currentStep.compressionCount >= currentStep.requiredCompressions) {
                    stepManager.completeCurrentStep();
                    updateInstructionText();
                }
            } else {
                // Complete step immediately for other types
                stepManager.completeCurrentStep();
                updateInstructionText();
                
                // Visual feedback
                hitObject.material.emissive = new THREE.Color(0x00ff00);
                setTimeout(() => {
                    if (hitObject.material.emissive) {
                        hitObject.material.emissive = new THREE.Color(0x000000);
                    }
                }, 200);
            }
        }
    }
}

function setupDesktopControls() {
    // OrbitControls for camera movement with mouse
    controls = new OrbitControls(camera, renderer.domElement);
    controls.target.set(0, 0.2, -2); // Look at the victim on the ground
    controls.update();
    controls.enableDamping = true;
    controls.dampingFactor = 0.05;
    controls.minDistance = 1;
    controls.maxDistance = 10;
    controls.maxPolarAngle = Math.PI / 2; // 不能转到地板下面

    // Mouse for raycasting
    mouse = new THREE.Vector2();
    hoveredObject = null;

    // Mouse move event for highlighting
    window.addEventListener('mousemove', onMouseMove);
    
    // Mouse click event for interaction
    window.addEventListener('click', onMouseClick);
}

function onMouseMove(event) {
    // Calculate mouse position in normalized device coordinates (-1 to +1)
    mouse.x = (event.clientX / window.innerWidth) * 2 - 1;
    mouse.y = -(event.clientY / window.innerHeight) * 2 + 1;

    // Update raycaster
    raycaster.setFromCamera(mouse, camera);

    // Check for intersections
    const intersects = raycaster.intersectObjects(interactableObjects, true);

    // Reset previous hovered object
    if (hoveredObject && hoveredObject.material.emissive) {
        hoveredObject.material.emissive.setHex(hoveredObject.userData.originalEmissive || 0x000000);
    }

    // Highlight new hovered object
    if (intersects.length > 0 && !stepManager.isFinished()) {
        hoveredObject = intersects[0].object;
        if (!hoveredObject.userData.originalEmissive) {
            hoveredObject.userData.originalEmissive = hoveredObject.material.emissive.getHex();
        }
        
        const currentStep = stepManager.getCurrentStep();
        if (hoveredObject.userData.type === currentStep.type) {
            hoveredObject.material.emissive.setHex(0x444444);
            document.body.style.cursor = 'pointer';
        } else {
            document.body.style.cursor = 'default';
        }
    } else {
        hoveredObject = null;
        document.body.style.cursor = 'default';
    }
}

function onMouseClick(event) {
    if (stepManager.isFinished()) {
        return;
    }

    // Update raycaster
    raycaster.setFromCamera(mouse, camera);

    // Check for intersections
    const intersects = raycaster.intersectObjects(interactableObjects, true);

    if (intersects.length > 0) {
        const hitObject = intersects[0].object;
        const currentStep = stepManager.getCurrentStep();

        // Check if the hit object matches the current step type
        if (hitObject.userData.type === currentStep.type) {
            // Special handling for compressions
            if (currentStep.type === "CHEST_COMPRESSIONS") {
                currentStep.compressionCount++;
                updateInstructionText();
                
                // Visual feedback
                hitObject.material.emissive.setHex(0xff0000);
                setTimeout(() => {
                    hitObject.material.emissive.setHex(hitObject.userData.originalEmissive || 0x000000);
                }, 100);
                
                if (currentStep.compressionCount >= currentStep.requiredCompressions) {
                    stepManager.completeCurrentStep();
                    updateInstructionText();
                }
            } else {
                // Complete step immediately for other types
                stepManager.completeCurrentStep();
                updateInstructionText();
                
                // Visual feedback
                hitObject.material.emissive.setHex(0x00ff00);
                setTimeout(() => {
                    if (hitObject.material.emissive) {
                        hitObject.material.emissive.setHex(hitObject.userData.originalEmissive || 0x000000);
                    }
                }, 200);
            }
        }
    }
}

function onWindowResize() {
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight);
}

function animate() {
    // Update controls if in desktop mode
    if (controls) {
        controls.update();
    }
    
    renderer.render(scene, camera);
}

// Initialize the application
init();
